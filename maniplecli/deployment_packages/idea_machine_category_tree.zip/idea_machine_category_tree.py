import boto3
import json
import logging

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)


def handler(event, context):
    LOGGER.info(event)
    response = {}
    s3 = boto3.resource('s3')
    for key, category in event.items():
        object = s3.Object('idea-machine-json-files',
                           'category_tree' + category + '.json')
        file = object.get()['Body'].read().decode('utf-8')
        data = json.loads(file)
        response[key] = data['categories']
    return response
